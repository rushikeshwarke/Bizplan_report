﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace BEBIZ.Upload.Sheets
{
    public class SLVolume : BaseSheet
    {

        public SLVolume(DataSet ds)
            : base(ds)
        {
            


        }

        protected override void Init()
        {
            RowNumber = 3;//what should be the row number?
            SheetName = "SL_Vol";
            TableName = "BizPlan_SL_Volume";
            MandatoryColumns = new string[] { "Service Line", "Services Type" };//SL changed to Service Line
            DuplicateColumns = new string[] { "Service Line", "Services Type" };//SL changed to Service Line
            NumericColumns = new string[] { "Q1'20 EST RPP (USD)", "Q2'20 EST RPP (USD)", "Q3'20 EST RPP (USD)", "Q4'20 EST RPP (USD)", "Q1'21 EST RPP", "Q2'21 EST RPP", "Q3'21 EST RPP", "Q4'21 EST RPP", "Q1'22 EST RPP", "Q2'22 EST RPP", "Q3'22 EST RPP", "Q4'22 EST RPP",
            "Q1'23 EST RPP","Q2'23 EST RPP","Q3'23 EST RPP","Q4'23 EST RPP"};//changed
            DictMapping.Add("Service Line", "SL"); //changed
            DictMapping.Add("Services Type", "Services_Type");
            //DictMapping.Add("Q1'19 EST RPP (USD)", "FY1Q1_EST_RPP_USD");
            //DictMapping.Add("Q2'19 EST RPP (USD)", "FY1Q2_EST_RPP_USD");
            //DictMapping.Add("Q3'19 EST RPP (USD)", "FY1Q3_EST_RPP_USD");
            //DictMapping.Add("Q4'19 EST RPP (USD)", "FY1Q4_EST_RPP_USD");
            //DictMapping.Add("Notes for RPP changes", "FY1_Notes_for_RPP_changes");


            DictMapping.Add("Q1'20 EST RPP (USD)", "FY1Q1_EST_RPP_USD");                //column mapping changed
            DictMapping.Add("Q2'20 EST RPP (USD)", "FY1Q2_EST_RPP_USD");                //column mapping changed
            DictMapping.Add("Q3'20 EST RPP (USD)", "FY1Q3_EST_RPP_USD");                //column mapping changed
            DictMapping.Add("Q4'20 EST RPP (USD)", "FY1Q4_EST_RPP_USD");                //column mapping changed
            DictMapping.Add("Remarks for RPP", "FY1_Notes_for_RPP_changes");            //column mapping changed
            DictMapping.Add("Q1'21 EST RPP", "FY2Q1_EST_RPP_USD");                      //column mapping changed
            DictMapping.Add("Q2'21 EST RPP", "FY2Q2_EST_RPP_USD");                      //column mapping changed
            DictMapping.Add("Q3'21 EST RPP", "FY2Q3_EST_RPP_USD");                      //column mapping changed
            DictMapping.Add("Q4'21 EST RPP", "FY2Q4_EST_RPP_USD");                      //column mapping changed
            DictMapping.Add("Remarks for RPP1", "FY2_Notes_for_RPP_changes");            //column mapping changed
            DictMapping.Add("Q1'22 EST RPP", "FY3Q1_EST_RPP_USD");                      //column mapping changed
            DictMapping.Add("Q2'22 EST RPP", "FY3Q2_EST_RPP_USD");                      //column mapping changed
            DictMapping.Add("Q3'22 EST RPP", "FY3Q3_EST_RPP_USD");                      //column mapping changed
            DictMapping.Add("Q4'22 EST RPP", "FY3Q4_EST_RPP_USD");                      //column mapping changed
            DictMapping.Add("Remarks for RPP2", "FY3_Notes_for_RPP_changes");            //column mapping changed


            DictMapping.Add("Q1'23 EST RPP", "FY4Q1_EST_RPP_USD");                      
            DictMapping.Add("Q2'23 EST RPP", "FY4Q2_EST_RPP_USD");                      
            DictMapping.Add("Q3'23 EST RPP", "FY4Q3_EST_RPP_USD");                      
            DictMapping.Add("Q4'23 EST RPP", "FY4Q4_EST_RPP_USD");                      
            DictMapping.Add("Remarks for RPP3", "FY4_Notes_for_RPP_changes");            

        }

       
    }
}