﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace BEBIZ.Upload.Sheets
{
    public class InOrganicSLRev : BaseSheet
    {
        public InOrganicSLRev(DataSet ds) : base(ds)
        {
            

             
        }

        protected override void Init()
        {
            RowNumber = 3;//what should be the row number?
            SheetName = "In-Organic_Rev (M&A)";//changed
            TableName = "BizPlan_InOrganic_SL_Revenue";
            MandatoryColumns = new string[] { "Service Line"};//changed. And no Services Type present.
            DuplicateColumns = new string[] { "Service Line", "Dimension", "Focus Area" };//changed. And no Services Type present.
            NumericColumns = new string[] { "Q1'23 EST REV in KUSD", "Q2'23 EST REV in KUSD", "Q3'23 EST REV in KUSD", "Q4'23 EST REV in KUSD", "Q1'21 EST REV in KUSD", "Q2'21 EST REV in KUSD", "Q3'21 EST REV in KUSD", "Q4'21 EST REV in KUSD",
            "Q1'22 EST REV in KUSD", "Q2'22 EST REV in KUSD", "Q3'22 EST REV in KUSD", "Q4'22 EST REV in KUSD"};//changed

            DictMapping.Add("Service Line", "SL");//changed

            //DictMapping.Add("Services Type", "Services_Type");

            DictMapping.Add("Dimension", "Dimension");//added
            DictMapping.Add("Focus Area", "Focus_Area");//added
            DictMapping.Add("Focus Sub-Area _(Optional)", "Focus_Sub_Area");//added
            DictMapping.Add("M&A Pipeline _(Name of the possible candidate)", "M&A_Pipeline");//added
            DictMapping.Add("Shortlisted? (Y/N)", "Shortlisted");//added
            DictMapping.Add("Remarks", "Remarks");
            //DictMapping.Add("Q1'19 EST REV in KUSD", "FY1Q1_EST_REV_KUSD");
            //DictMapping.Add("Q2'19 EST REV in KUSD", "FY1Q2_EST_REV_KUSD");
            //DictMapping.Add("Q3'19 EST REV in KUSD", "FY1Q3_EST_REV_KUSD");
            //DictMapping.Add("Q4'19 EST REV in KUSD", "FY1Q4_EST_REV_KUSD");
            DictMapping.Add("Q1'21 EST REV in KUSD", "FY1Q1_EST_REV_KUSD");
            DictMapping.Add("Q2'21 EST REV in KUSD", "FY1Q2_EST_REV_KUSD");
            DictMapping.Add("Q3'21 EST REV in KUSD", "FY1Q3_EST_REV_KUSD");
            DictMapping.Add("Q4'21 EST REV in KUSD", "FY1Q4_EST_REV_KUSD");
            DictMapping.Add("Q1'22 EST REV in KUSD", "FY2Q1_EST_REV_KUSD");
            DictMapping.Add("Q2'22 EST REV in KUSD", "FY2Q2_EST_REV_KUSD");
            DictMapping.Add("Q3'22 EST REV in KUSD", "FY2Q3_EST_REV_KUSD");
            DictMapping.Add("Q4'22 EST REV in KUSD", "FY2Q4_EST_REV_KUSD");

            DictMapping.Add("Q1'23 EST REV in KUSD", "FY3Q1_EST_REV_KUSD");//added
            DictMapping.Add("Q2'23 EST REV in KUSD", "FY3Q2_EST_REV_KUSD");//added
            DictMapping.Add("Q3'23 EST REV in KUSD", "FY3Q3_EST_REV_KUSD");//added
            DictMapping.Add("Q4'23 EST REV in KUSD", "FY3Q4_EST_REV_KUSD");//added
            //COLUMN MAPPING CHANGED
        }
    }

   
}