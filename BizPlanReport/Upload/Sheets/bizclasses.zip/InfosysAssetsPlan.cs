﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace BEBIZ.Upload.Sheets
{
    public class InfosysAssetsPlan:BaseSheet
    {
        public InfosysAssetsPlan(DataSet ds, string sl)
            : base(ds, sl)
        {

        }


        protected override void Init()
        {
            RowNumber = 5;
            SheetName = "Infosys Assets Plan";
            TableName = "BizPlan_Infosys_Assets_Plan";
            if (SL.ToLower() == "orc" || SL.ToLower() == "sap")
            {


                MandatoryColumns = new string[] { "Service Line", "Sub unit", "Name of Infosys Asset/IP", "Master Customer Code", "Is the revenue currently reported under digital business? Yes/No" };//SL changed to Service Line
                DuplicateColumns = new string[] { "Service Line", "Sub unit", "Name of Infosys Asset/IP", "Master Customer Code", "Is the revenue currently reported under digital business? Yes/No" };//SL //changed to Service Line
            }
            else
            {
                // ECAS and EAIS
                MandatoryColumns = new string[] { "Service Line", "Sub unit", "Name of Infosys Asset/IP", "Master Customer Code", "Is the revenue currently reported under digital business? Yes/No" };// for ecas and eais
                DuplicateColumns = new string[] { "Service Line", "Sub unit", "Name of Infosys Asset/IP", "Master Customer Code", "Is the revenue currently reported under digital business? Yes/No" }; //// for ecas and eais
            }

            NumericColumns = new string[] {
                "Q1'21","Q2'21","Q3'21","Q4'21",
                "Q1'22","Q2'22","Q3'22","Q4'22",
                "Q1 FY23 _(Plan)","Q2 FY23 _(Plan)","Q3 FY23 _(Plan)","Q4 FY23 _(Plan)",
               "FY24 (Plan)","FY25 _(Plan)"

            };

            //"FY22 Quarterly delta %" ,"FY23 Quarterly delta %" , "FY24 Quarterly delta %" };

            DictMapping.Add("Service Line", "Service_Line");//changed
            DictMapping.Add("Sub unit", "Sub_unit");
            DictMapping.Add("Name of Infosys Asset/IP", "Name_of_Infosys_Asset/IP");
            DictMapping.Add("Is Asset published in Service Store (Yes/No)", "Is_Asset_published_in_Service_Store");
            DictMapping.Add("Master Customer Code", "Master_Customer_Code");
            DictMapping.Add("Is the revenue currently reported under digital business? Yes/No", "Is_the_revenue_currently_reported_under_digital_business");//added
            DictMapping.Add("Is yes, please mention the Digital Services Name", "Is_yes_please_mention_the_Digital_Services_Name");//added
            
            DictMapping.Add("Q1'21", "Q1'21");
            DictMapping.Add("Q2'21", "Q2'21");
            DictMapping.Add("Q3'21", "Q3'21");
            DictMapping.Add("Q4'21", "Q4'21");

            DictMapping.Add("Q1'22", "Q1'22");
            DictMapping.Add("Q2'22", "Q2'22");
            DictMapping.Add("Q3'22", "Q3'22");
            DictMapping.Add("Q4'22", "Q4'22");

            DictMapping.Add("Q1 FY23 _(Plan)", "Q1_FY23(Plan)");
            DictMapping.Add("Q2 FY23 _(Plan)", "Q2_FY23(Plan)");
            DictMapping.Add("Q3 FY23 _(Plan)", "Q3_FY23(Plan)");
            DictMapping.Add("Q4 FY23 _(Plan)", "Q4_FY23(Plan)");
           
         
            DictMapping.Add("FY24 (Plan)", "Q4_FY24(Plan)");

           
            DictMapping.Add("FY25 _(Plan)", "Q4_FY25(Plan)");

        }


     


    }
}