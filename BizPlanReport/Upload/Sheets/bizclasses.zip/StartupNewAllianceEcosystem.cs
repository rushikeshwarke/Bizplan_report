﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace BEBIZ.Upload.Sheets
{
    public class StartupNewAllianceEcosystem:BaseSheet
    {
        public StartupNewAllianceEcosystem(DataSet ds, string sl)
           : base(ds, sl)
        {

        }


        protected override void Init()
        {
            RowNumber = 5;
            SheetName = "Startup&New Alliance Ecosystem";
            TableName = "BizPlan_Startup_New_Alliance_Ecosystem";
            if (SL.ToLower() == "orc" || SL.ToLower() == "sap")
            {
                

                MandatoryColumns = new string[] { "Service Line", "Sub unit", "Name of the Startup/Alliance", "Master Customer Code", "Service Area", "Any Deal Closed (Won/Open)" };//SL changed to Service Line
                DuplicateColumns = new string[] { "Service Line", "Sub unit", "Name of the Startup/Alliance", "Master Customer Code", "Service Area", "Any Deal Closed (Won/Open)" };//SL //changed to Service Line
            }
            else
            {
                // ECAS and EAIS
                MandatoryColumns = new string[] { "Service Line", "Sub unit", "Name of the Startup/Alliance", "Master Customer Code", "Service Area", "Any Deal Closed (Won/Open)" };// for ecas and eais
                DuplicateColumns = new string[] { "Service Line", "Sub unit", "Name of the Startup/Alliance", "Master Customer Code", "Service Area", "Any Deal Closed (Won/Open)" }; //// for ecas and eais
            }

            NumericColumns = new string[] {
               "Q1'21","Q2'21","Q3'21","Q4'21",
                "Q1'22","Q2'22","Q3'22","Q4'22",
                "Q1 FY23 _(Plan)","Q2 FY23 _(Plan)","Q3 FY23 _(Plan)","Q4 FY23 _(Plan)",
                "FY23 (Plan)",
                "FY24 (Plan)",
                "FY25 _(Plan)"

            };

            //"FY22 Quarterly delta %" ,"FY23 Quarterly delta %" , "FY24 Quarterly delta %" };

            DictMapping.Add("Service Line", "Service_Line");//changed
            DictMapping.Add("Sub unit", "Sub_unit");
            DictMapping.Add("Name of the Startup/Alliance", "Name_of_the_Startup/Alliance");
            DictMapping.Add("Master Customer Code", "Master_Customer_Code");
            DictMapping.Add("Service Area", "Service_Area");
            DictMapping.Add("Any Deal Closed (Won/Open)", "Any_Deal_Closed");//added
            DictMapping.Add("TCV of the Deal _(KUSD)", "TCV_of_the_Deal_KUSD");//added
            
        

            DictMapping.Add("Q1'21", "Q1'21");
            DictMapping.Add("Q2'21", "Q2'21");
            DictMapping.Add("Q3'21", "Q3'21");
            DictMapping.Add("Q4'21", "Q4'21");

            DictMapping.Add("Q1'22", "Q1'22");
            DictMapping.Add("Q2'22", "Q2'22");
            DictMapping.Add("Q3'22", "Q3'22");
            DictMapping.Add("Q4'22", "Q4'22");

            DictMapping.Add("Q1 FY23 _(Plan)", "Q1_FY23(Plan)");
            DictMapping.Add("Q2 FY23 _(Plan)", "Q2_FY23(Plan)");
            DictMapping.Add("Q3 FY23 _(Plan)", "Q3_FY23(Plan)");
            DictMapping.Add("Q4 FY23 _(Plan)", "Q4_FY23(Plan)");


            DictMapping.Add("FY24 (Plan)", "Q4_FY24(Plan)");


            DictMapping.Add("FY25 _(Plan)", "Q4_FY25(Plan)");

        }



    }
}