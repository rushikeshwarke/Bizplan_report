﻿using BEBIZ4.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace BEBIZ.Upload.Sheets
{
    public class Investment_SL_Practice_Sales : BaseSheet
    {
        public Investment_SL_Practice_Sales(DataSet ds, string sl) : base(ds, sl) { }

        protected override void Init()
        {
            RowNumber = 3;
            SheetName = "Investment_SL_Practice_Sales";
            TableName = "BizPlan_SL_Practice_Sales_Investment";
            MandatoryColumns = new string[] { "Service Line" };
            DuplicateColumns = new string[] { "Service Line", "Geo", "Country", "Offering Area", "Investment Category ", "Remarks" };
            NumericColumns = new string[] {

            "Q1'23 EST INV", "Q2'23 EST INV", "Q3'23 EST INV", "Q4'23 EST INV",
            "Q1'24 EST INV", "Q2'24 EST INV", "Q3'24 EST INV", "Q4'24 EST INV",
            "Q1'25 EST INV", "Q2'25 EST INV", "Q3'25 EST INV", "Q4'25 EST INV"

               // "FY23 Quarterly delta %","FY21 Quarterly delta %",
            //"FY22 Quarterly delta %"
            };
            DictLookUpMapping.Add("Investment Category ",EnumLookUp.InvestmentCategory_PracticeSales);

            DictMapping.Add("Service Line", "SL");
            DictMapping.Add("Geo", "Geo");
            DictMapping.Add("Country", "Country");
            DictMapping.Add("Offering Area", "Offering_Area");
            DictMapping.Add("Investment Category ", "Investment_Category");
            DictMapping.Add("Remarks", "Remarks");


            DictMapping.Add("Q1'23 EST INV", "FY2Q1_EST_INV");
            DictMapping.Add("Q2'23 EST INV", "FY2Q2_EST_INV");
            DictMapping.Add("Q3'23 EST INV", "FY2Q3_EST_INV");
            DictMapping.Add("Q4'23 EST INV", "FY2Q4_EST_INV");

            DictMapping.Add("Q1'24 EST INV", "FY3Q1_EST_INV");
            DictMapping.Add("Q2'24 EST INV", "FY3Q2_EST_INV");
            DictMapping.Add("Q3'24 EST INV", "FY3Q3_EST_INV");
            DictMapping.Add("Q4'24 EST INV", "FY3Q4_EST_INV");

            DictMapping.Add("Q1'25 EST INV", "FY3Q1_EST_INV");
            DictMapping.Add("Q2'25 EST INV", "FY3Q2_EST_INV");
            DictMapping.Add("Q3'25 EST INV", "FY3Q3_EST_INV");
            DictMapping.Add("Q4'25 EST INV", "FY3Q4_EST_INV");


            //DictMapping.Add("FY21 Quarterly delta %", "FY1_Quarterly_Delta_Perc");
            //DictMapping.Add("FY22 Quarterly delta %", "FY2_Quarterly_Delta_Perc");
            //DictMapping.Add("FY23 Quarterly delta %", "FY3_Quarterly_Delta_Perc");




        }
    }

   
}